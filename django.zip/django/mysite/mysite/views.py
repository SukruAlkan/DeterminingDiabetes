from django.http import HttpResponse
from django.shortcuts import render
import joblib


def home(request):
    return render(request, "home.html")


def result(request):
    cls = joblib.load('finalized_model.sav')

    lis = []

    lis.append(request.GET['Age'])
    lis.append(request.GET['Gender'])
    lis.append(request.GET['Polyuria'])
    lis.append(request.GET['Polydipsia'])
    lis.append(request.GET['sudden weight loss'])
    lis.append(request.GET['weakness'])
    lis.append(request.GET['Polyphagia'])
    lis.append(request.GET['Genital thrush'])
    lis.append(request.GET['visual blurring'])
    lis.append(request.GET['Itching'])
    lis.append(request.GET['Irritability'])
    lis.append(request.GET['delayed healing'])
    lis.append(request.GET['partial paresis'])
    lis.append(request.GET['muscle stiffness'])
    lis.append(request.GET['Alopecia'])
    lis.append(request.GET['Obesity'])

    ans = cls.predict([lis])

    return render(request, "result.html", {'ans': ans, 'lis': lis})
